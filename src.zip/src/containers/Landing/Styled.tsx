import styled from 'styled-components';

export const DashboardWrrapper = styled.div`
  padding: 1.75rem 2rem 6rem 2rem;
  background: #f4f5fc;
  color: rgba(0, 0, 0, 0.87);
  margin-top: 65px;
`;
