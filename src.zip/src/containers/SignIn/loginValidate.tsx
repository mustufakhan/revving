const loginValidate = [
  {
    field: 'username',
    validations: ['required'],
    name: 'User name'
  },
  {
    field: 'password',
    validations: ['required'],
    name: 'Password'
  }
];

export default loginValidate;
