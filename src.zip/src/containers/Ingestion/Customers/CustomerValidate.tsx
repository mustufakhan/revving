const customerValidate = [
  {
    field: 'name',
    validations: ['required'],
    name: 'Customer name'
  }
];

export default customerValidate;
