const masterRevenueValidate = [
  {
    field: 'masterName',
    validations: ['required'],
    name: 'Master Revenue name'
  }
];

export default masterRevenueValidate;
