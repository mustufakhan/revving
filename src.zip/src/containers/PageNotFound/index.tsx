import React from 'react';

export const PageNotFound = () => <div>Page not found</div>;

export default PageNotFound;
